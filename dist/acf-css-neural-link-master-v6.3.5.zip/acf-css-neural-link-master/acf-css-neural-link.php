<?php
/**
 * Plugin Name:       ACF CSS Neural Link - License & Update Manager (Advanced Custom Fonts & Colors & Styles)
 * Plugin URI:        https://3j-labs.com/
 * Description:       ACF CSS (Advanced Custom Fonts & Colors & Styles) 플러그인의 라이센스 인증, 자동 업데이트, 원격 제어를 담당하는 중앙 관리 시스템입니다. WooCommerce와 연동하여 라이센스를 자동으로 발행하고 관리합니다.
 * Version:           6.3.5
 * Author:            3J Labs (제이x제니x제이슨 연구소)
 * Created by:        Jay & Jason & Jenny
 * Author URI:        https://3j-labs.com/
 * Text Domain:       acf-css-neural-link
 * Domain Path:       /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * 개발 원칙 (필수 준수)
 * 
 * 이 플러그인의 모든 코드 수정 및 개발은 다음 원칙을 반드시 준수해야 합니다:
 * 
 * ⚠️ 중요: Git 경로와 로컬 경로는 완전히 별개입니다
 * - 로컬 작업 경로: C:\Users\computer\OneDrive\Desktop\클라우드 백업\OneDrive\문서\jj-css-premium
 * - Git worktree 경로: C:\Users\computer\.cursor\worktrees\jj-css-premium\tci
 * - 두 경로는 서로 독립적이며, Git에서 작업한 내용은 반드시 로컬 경로에 동기화해야 함
 * 
 * 1. WordPress 함수 호출 시점 안전성
 *    - 모든 WordPress 함수 호출 전 function_exists() 확인 필수
 *    - plugin_dir_path(), plugin_dir_url(), plugin_basename() 등
 *    - WordPress가 완전히 로드되기 전에도 안전하게 작동해야 함
 * 
 * 2. 클래스 속성에 상수 직접 할당 금지
 *    - PHP Parse Error 방지를 위해 생성자에서 할당
 * 
 * 3. WordPress 상수를 클래스 속성에서 직접 사용 금지
 *    - DAY_IN_SECONDS 등은 생성자에서 확인 후 사용
 * 
 * 4. 활성화 훅 안전성 확보
 *    - 모든 활성화 로직은 try-catch 블록으로 감싸야 함
 *    - 파일/클래스 존재 확인 필수
 * 
 * 자세한 내용은 루트 디렉토리의 DEVELOPMENT_PRINCIPLES.md 파일을 참조하세요.
 */

// 플러그인 상수 정의
// [v2.1.0] 원격 제어 기능 강화, 로그 수집 및 분석 기능 추가, 업데이트 배포 및 공지 기능 추가, 보안 강화
// [v2.1.1] 버전 관리 및 기술 문서 보강: 문서화 개선 및 버전 업데이트
// [v2.1.2] 플러그인 버전별 자동 업데이트 제어 기능 추가, dev 버전과의 호환성 개선
// [v2.1.3] 플러그인 폴더명 및 슬러그 업데이트
// [v2.1.4] Pro 버전 원격 활성화 시스템 지원
define( 'JJ_NEURAL_LINK_VERSION', '6.3.5' ); // [v6.3.5] 버전 업데이트 - 문서 및 빌드 업데이트

// WordPress 함수가 로드되었는지 확인 후 상수 정의
if ( ! defined( 'JJ_NEURAL_LINK_PATH' ) ) {
    if ( function_exists( 'plugin_dir_path' ) ) {
        define( 'JJ_NEURAL_LINK_PATH', plugin_dir_path( __FILE__ ) );
    } else {
        // WordPress가 로드되기 전에는 직접 경로 계산
        define( 'JJ_NEURAL_LINK_PATH', dirname( __FILE__ ) . DIRECTORY_SEPARATOR );
    }
}

if ( ! defined( 'JJ_NEURAL_LINK_URL' ) ) {
    if ( function_exists( 'plugin_dir_url' ) ) {
        define( 'JJ_NEURAL_LINK_URL', plugin_dir_url( __FILE__ ) );
    } else {
        // WordPress가 로드되기 전에는 기본값 사용 (나중에 업데이트됨)
        define( 'JJ_NEURAL_LINK_URL', '' );
    }
}

if ( ! defined( 'JJ_LICENSE_MANAGER_BASENAME' ) ) {
    if ( function_exists( 'plugin_basename' ) ) {
        define( 'JJ_LICENSE_MANAGER_BASENAME', plugin_basename( __FILE__ ) );
    } else {
        // WordPress가 로드되기 전에는 기본값 사용
        define( 'JJ_LICENSE_MANAGER_BASENAME', basename( dirname( __FILE__ ) ) . '/' . basename( __FILE__ ) );
    }
}

// 자동 로더 (WordPress가 로드된 후에만 실행)
if ( defined( 'JJ_NEURAL_LINK_PATH' ) && function_exists( 'class_exists' ) ) {
    $autoloader_file = JJ_NEURAL_LINK_PATH . 'includes/class-jj-license-autoloader.php';
    if ( file_exists( $autoloader_file ) ) {
        require_once $autoloader_file;
        if ( class_exists( 'JJ_License_Autoloader' ) ) {
            JJ_License_Autoloader::init();
        }
    }
    
    // Load Pattern Learner
    $pattern_learner_file = JJ_NEURAL_LINK_PATH . 'includes/class-jj-pattern-learner.php';
    if ( file_exists( $pattern_learner_file ) ) {
        require_once $pattern_learner_file;
    }
    
    // Load Pattern Learner Admin
    if ( is_admin() ) {
        $pattern_learner_admin_file = JJ_NEURAL_LINK_PATH . 'includes/admin/class-jj-pattern-learner-admin.php';
        if ( file_exists( $pattern_learner_admin_file ) ) {
            require_once $pattern_learner_admin_file;
        }
    }
    
    // Plugin List Enhancer 로드
    $plugin_list_enhancer_file = dirname( dirname( __FILE__ ) ) . '/acf-css-really-simple-style-management-center-master/includes/class-jj-plugin-list-enhancer.php';
    if ( file_exists( $plugin_list_enhancer_file ) ) {
        require_once $plugin_list_enhancer_file;
    }
}

/**
 * WooCommerce HPOS(High-Performance Order Storage) 호환성 선언
 */
add_action( 'before_woocommerce_init', function() {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
} );

// 플러그인 목록 페이지 향상 초기화
function jj_neural_link_init_plugin_list_enhancer() {
    if ( class_exists( 'JJ_Plugin_List_Enhancer' ) ) {
        $enhancer = new JJ_Plugin_List_Enhancer();
        $enhancer->init( array(
            'plugin_file' => __FILE__,
            'plugin_name' => 'ACF CSS Neural Link',
            'settings_url' => admin_url( 'admin.php?page=jj-license-manager' ),
            'text_domain' => 'acf-css-neural-link',
            'version_constant' => 'JJ_NEURAL_LINK_VERSION',
            'license_constant' => 'JJ_LICENSE_MANAGER_LICENSE_TYPE',
            'upgrade_url' => 'https://3j-labs.com/',
            'docs_url' => admin_url( 'admin.php?page=jj-license-manager' ),
            'support_url' => 'https://3j-labs.com/support',
        ) );
    }
}
add_action( 'plugins_loaded', 'jj_neural_link_init_plugin_list_enhancer', 25 );

// 플러그인 초기화
function jj_license_manager_init() {
    // WooCommerce 활성화 확인 (경고만 표시, 활성화는 허용)
    if ( ! class_exists( 'WooCommerce' ) ) {
        add_action( 'admin_notices', 'jj_license_manager_woocommerce_notice' );
        // WooCommerce가 없어도 플러그인은 활성화 가능하도록 계속 진행
        // return; // 주석 처리하여 활성화 허용
    }
    
    // 메인 클래스 존재 확인 후 인스턴스 생성
    if ( ! class_exists( 'JJ_License_Manager_Main' ) ) {
        // 클래스가 로드되지 않은 경우 직접 로드 시도
        $main_class_file = JJ_NEURAL_LINK_PATH . 'includes/class-jj-license-manager-main.php';
        if ( file_exists( $main_class_file ) ) {
            require_once $main_class_file;
        } else {
            add_action( 'admin_notices', function() {
                echo '<div class="notice notice-warning"><p>';
                echo '<strong>' . esc_html__( 'JJ License Manager', 'jj-license-manager' ) . '</strong>: ';
                echo esc_html__( '일부 파일을 찾을 수 없습니다. 플러그인 기능이 제한될 수 있습니다.', 'jj-license-manager' );
                echo '</p></div>';
            } );
            // 파일이 없어도 플러그인은 활성화 가능하도록 계속 진행
            // return; // 주석 처리하여 활성화 허용
        }
    }
    
    // 메인 클래스 인스턴스 생성 (클래스가 있을 때만)
    if ( class_exists( 'JJ_License_Manager_Main' ) ) {
        try {
            JJ_License_Manager_Main::instance();
        } catch ( Exception $e ) {
            if ( function_exists( 'error_log' ) ) {
                error_log( 'JJ License Manager Init Error: ' . $e->getMessage() );
            }
        }
    }
    
    // Initialize Pattern Learner
    if ( class_exists( 'JJ_Pattern_Learner' ) ) {
        JJ_Pattern_Learner::instance();
    }
    
    // Initialize Pattern Learner Admin
    if ( is_admin() && class_exists( 'JJ_Pattern_Learner_Admin' ) ) {
        JJ_Pattern_Learner_Admin::instance();
    }
}
add_action( 'plugins_loaded', 'jj_license_manager_init', 20 );

/**
 * WooCommerce 미활성화 알림
 */
function jj_license_manager_woocommerce_notice() {
    ?>
    <div class="notice notice-error">
        <p>
            <strong><?php esc_html_e( 'JJ License Manager', 'jj-license-manager' ); ?></strong>: 
            <?php esc_html_e( '이 플러그인은 WooCommerce가 필요합니다. WooCommerce를 설치하고 활성화해주세요.', 'jj-license-manager' ); ?>
        </p>
    </div>
    <?php
}

/**
 * 플러그인 활성화 훅
 * [v2.0.1] 전체 함수를 try-catch로 감싸고 상수 정의 확인 추가
 */
register_activation_hook( __FILE__, 'jj_license_manager_activate' );
function jj_license_manager_activate() {
    try {
        // 상수 정의 확인
        if ( ! defined( 'JJ_NEURAL_LINK_PATH' ) ) {
            // 상수가 정의되지 않은 경우 기본 경로 사용
            if ( function_exists( 'plugin_dir_path' ) ) {
                define( 'JJ_NEURAL_LINK_PATH', plugin_dir_path( __FILE__ ) );
            } else {
                define( 'JJ_NEURAL_LINK_PATH', dirname( __FILE__ ) . DIRECTORY_SEPARATOR );
            }
        }
        
        // 데이터베이스 테이블 생성
        $db_file = JJ_NEURAL_LINK_PATH . 'includes/class-jj-license-database.php';
        if ( file_exists( $db_file ) ) {
            require_once $db_file;
            if ( class_exists( 'JJ_License_Database' ) ) {
                JJ_License_Database::create_tables();
            }
        }
        
        // 기본 옵션 설정
        if ( function_exists( 'add_option' ) ) {
            add_option( 'jj_license_manager_version', defined( 'JJ_NEURAL_LINK_VERSION' ) ? JJ_NEURAL_LINK_VERSION : '3.9.9' );
            add_option( 'jj_license_manager_activation_time', time() );
        }
        
        // Cron 작업 스케줄링
        if ( function_exists( 'wp_next_scheduled' ) && function_exists( 'wp_schedule_event' ) ) {
            if ( ! wp_next_scheduled( 'jj_license_manager_daily_check' ) ) {
                wp_schedule_event( time(), 'daily', 'jj_license_manager_daily_check' );
            }
        }
        
        // dev 버전과의 호환성: dev 버전이 활성화되어 있어도 문제없이 작동하도록
        // WooCommerce 의존성은 plugins_loaded에서 체크하므로 활성화 시에는 체크하지 않음

        // [v6.3.3] 파일 무결성 해시 초기화 - 라이센스 변조 감지용
        $security_file = JJ_NEURAL_LINK_PATH . 'includes/class-jj-license-security.php';
        if ( file_exists( $security_file ) ) {
            require_once $security_file;
            if ( class_exists( 'JJ_License_Security' ) && method_exists( 'JJ_License_Security', 'store_file_hashes' ) ) {
                JJ_License_Security::store_file_hashes( JJ_NEURAL_LINK_PATH );
            }
        }
    } catch ( Exception $e ) {
        if ( function_exists( 'error_log' ) ) {
            error_log( 'JJ License Manager: 활성화 중 오류 - ' . $e->getMessage() );
        }
    } catch ( Error $e ) {
        if ( function_exists( 'error_log' ) ) {
            error_log( 'JJ License Manager: 활성화 중 치명적 오류 - ' . $e->getMessage() );
        }
    }
}

/**
 * 플러그인 비활성화 훅
 */
register_deactivation_hook( __FILE__, 'jj_license_manager_deactivate' );
function jj_license_manager_deactivate() {
    try {
        // Cron 작업 제거
        if (function_exists('wp_clear_scheduled_hook')) {
            wp_clear_scheduled_hook( 'jj_license_manager_daily_check' );
        }
    } catch (Exception $e) {
        if (function_exists('error_log')) {
            error_log('JJ License Manager Deactivation Error: ' . $e->getMessage());
        }
    }
}



// Server API 로드 (파일 존재 확인 후 로드)
$server_api_file = JJ_NEURAL_LINK_PATH . 'includes/api/class-jj-neural-link-server-api.php';
if (file_exists($server_api_file)) {
    try {
        require_once $server_api_file;
        if (class_exists('JJ_Neural_Link_Server_API')) {
            add_action( 'plugins_loaded', array( 'JJ_Neural_Link_Server_API', 'instance' ) );
        }
    } catch (Exception $e) {
        if (function_exists('error_log')) {
            error_log('JJ Neural Link: Failed to load Server API: ' . $e->getMessage());
        }
    }
}


// Version Manager 로드 (관리자용)
if ( is_admin() ) {
    require_once JJ_NEURAL_LINK_PATH . 'includes/admin/class-jj-neural-link-version-manager.php';
    add_action( 'plugins_loaded', array( 'JJ_Neural_Link_Version_Manager', 'instance' ) );
}


// Cloud API 로드
require_once JJ_NEURAL_LINK_PATH . 'includes/api/class-jj-neural-link-cloud-api.php';
add_action( 'plugins_loaded', array( 'JJ_Neural_Link_Cloud_API', 'instance' ) );


// [v3.2.0] License REST API 로드 (WooCommerce 연동용)
if ( file_exists( JJ_NEURAL_LINK_PATH . 'includes/class-jj-neural-link-woo-api.php' ) ) {
    require_once JJ_NEURAL_LINK_PATH . 'includes/class-jj-neural-link-woo-api.php';
    // init 훅에서 자동으로 instance 호출됨 (class 파일 내 add_action 확인)
}

// [v3.3.0] Launcher API 로드 (3J Labs Launcher 연동용)
if ( file_exists( JJ_NEURAL_LINK_PATH . 'includes/api/class-jj-neural-link-launcher-api.php' ) ) {
    require_once JJ_NEURAL_LINK_PATH . 'includes/api/class-jj-neural-link-launcher-api.php';
}

// [v4.2.0] JJ Plugin Updater - WordPress 업데이트 시스템 통합
if ( file_exists( JJ_NEURAL_LINK_PATH . 'includes/class-jj-plugin-updater.php' ) ) {
    try {
        require_once JJ_NEURAL_LINK_PATH . 'includes/class-jj-plugin-updater.php';
        
        add_action( 'admin_init', function() {
            try {
                // Neural Link 자체 업데이트
                if ( class_exists( 'JJ_Plugin_Updater' ) ) {
                    $license_key = get_option( 'jj_license_manager_license_key', '' );
                    $api_url = get_option( 'jj_license_manager_server_url', 'https://3j-labs.com/' );

                    new JJ_Plugin_Updater(
                        $api_url,
                        __FILE__,
                        array(
                            'version'   => JJ_NEURAL_LINK_VERSION,
                            'license'   => $license_key,
                            'item_name' => 'ACF CSS Neural Link',
                            'author'    => '3J Labs',
                            'beta'      => false,
                        )
                    );
                }
            } catch (Exception $e) {
                if (function_exists('error_log')) {
                    error_log('JJ Neural Link: Plugin Updater init error: ' . $e->getMessage());
                }
            }
        } );
    } catch (Exception $e) {
        if (function_exists('error_log')) {
            error_log('JJ Neural Link: Failed to load Plugin Updater: ' . $e->getMessage());
        }
    }
}

/**
 * [v6.3.3] 플러그인 업데이트 완료 후 파일 해시 갱신
 *
 * WordPress의 upgrader_process_complete 훅을 사용하여
 * Neural Link 또는 관련 플러그인이 업데이트될 때 파일 해시를 갱신합니다.
 */
add_action( 'upgrader_process_complete', 'jj_neural_link_refresh_file_hashes', 10, 2 );
function jj_neural_link_refresh_file_hashes( $upgrader_object, $options ) {
    try {
        // 플러그인 업데이트인지 확인
        if ( !isset($options['action']) || !isset($options['type']) || $options['action'] !== 'update' || $options['type'] !== 'plugin' ) {
            return;
        }

        // JJ_License_Security 클래스 로드
        $security_file = JJ_NEURAL_LINK_PATH . 'includes/class-jj-license-security.php';
        if ( ! file_exists( $security_file ) ) {
            return;
        }

        try {
            require_once $security_file;
        } catch (Exception $e) {
            if (function_exists('error_log')) {
                error_log('JJ Neural Link: Failed to load Security class in refresh: ' . $e->getMessage());
            }
            return;
        }
        
        if ( ! class_exists( 'JJ_License_Security' ) || ! method_exists( 'JJ_License_Security', 'store_file_hashes' ) ) {
            return;
        }
    } catch (Exception $e) {
        if (function_exists('error_log')) {
            error_log('JJ Neural Link: Refresh file hashes error: ' . $e->getMessage());
        }
        return;
    }

    // 업데이트된 플러그인 목록 확인
    $plugins = isset( $options['plugins'] ) ? $options['plugins'] : array();
    if ( isset( $options['plugin'] ) ) {
        $plugins = array( $options['plugin'] );
    }

    // 3J Labs 플러그인 경로 패턴
    $jj_plugin_patterns = array(
        'acf-css-neural-link/',
        'acf-css-really-simple-style-management-center-master/',
        'wp-bulk-manager/',
        'acf-code-snippets-box/',
        'acf-mba-nudge-flow/',
        'acf-css-woo-toolkit/',
    );

    foreach ( $plugins as $plugin ) {
        foreach ( $jj_plugin_patterns as $pattern ) {
            if ( strpos( $plugin, $pattern ) !== false ) {
                try {
                    // 해당 플러그인 경로의 해시 갱신
                    $plugin_dir = WP_PLUGIN_DIR . '/' . dirname( $plugin ) . '/';
                    if ( is_dir( $plugin_dir ) ) {
                        JJ_License_Security::store_file_hashes( $plugin_dir );

                        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                            error_log( '[Neural Link] File hashes refreshed for: ' . $plugin );
                        }
                    }
                } catch (Exception $e) {
                    if (function_exists('error_log')) {
                        error_log('JJ Neural Link: Failed to refresh file hashes for ' . $plugin . ': ' . $e->getMessage());
                    }
                }
                break;
            }
        }
    }
}
