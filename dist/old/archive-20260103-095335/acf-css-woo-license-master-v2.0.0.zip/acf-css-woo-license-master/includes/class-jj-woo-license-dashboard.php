<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * [Phase 24] WooCommerce 라이센스 대시보드
 * - 마스터: 전체 판매 및 라이센스 현황 관리
 * - 파트너: 본인의 판매 내역 및 정산 현황 확인
 *
 * @since 20.2.2
 */
class JJ_Woo_License_Dashboard {

    private static $instance = null;
    private $edition = 'master';

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        if ( defined( 'ACF_CSS_WOO_LICENSE_EDITION' ) ) {
            $this->edition = ACF_CSS_WOO_LICENSE_EDITION;
        }
        
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action( 'admin_menu', array( $this, 'add_dashboard_menu' ), 20 );
    }

    /**
     * 대시보드 메뉴 추가
     */
    public function add_dashboard_menu() {
        $title = ( 'master' === $this->edition ) ? __( '판매 & 라이센스 센터', 'acf-css-woo-license' ) : __( '판매 현황 (파트너)', 'acf-css-woo-license' );
        
        add_submenu_page(
            'acf-css-woo-license',
            $title,
            $title,
            'manage_options',
            'acf-css-woo-license-dashboard',
            array( $this, 'render_dashboard' )
        );
    }

    /**
     * 대시보드 렌더링
     */
    public function render_dashboard() {
        ?>
        <div class="wrap">
            <h1><?php echo ( 'master' === $this->edition ) ? esc_html__( '🚀 3J Labs 판매 & 라이센스 센터 (Master)', 'acf-css-woo-license' ) : esc_html__( '📊 나의 판매 현황 (Partner)', 'acf-css-woo-license' ); ?></h1>
            
            <div class="jj-dashboard-stats" style="display: flex; gap: 20px; margin-top: 20px;">
                <div class="card" style="flex: 1; padding: 20px; text-align: center; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <h3><?php esc_html_e( '이번 달 판매량', 'acf-css-woo-license' ); ?></h3>
                    <p style="font-size: 2em; font-weight: bold; color: #2271b1;"><?php echo $this->get_monthly_sales_count(); ?>개</p>
                </div>
                <div class="card" style="flex: 1; padding: 20px; text-align: center; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <h3><?php esc_html_e( '활성 라이센스', 'acf-css-woo-license' ); ?></h3>
                    <p style="font-size: 2em; font-weight: bold; color: #00a32a;"><?php echo $this->get_active_license_count(); ?>개</p>
                </div>
                <?php if ( 'partner' === $this->edition ) : ?>
                <div class="card" style="flex: 1; padding: 20px; text-align: center; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <h3><?php esc_html_e( '예상 정산 금액', 'acf-css-woo-license' ); ?></h3>
                    <p style="font-size: 2em; font-weight: bold; color: #d63638;"><?php echo number_format( $this->get_partner_earnings() ); ?>원</p>
                </div>
                <?php endif; ?>
            </div>

            <div class="jj-recent-orders" style="margin-top: 30px;">
                <h2><?php esc_html_e( '최근 주문 및 라이센스 발행 내역', 'acf-css-woo-license' ); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( '주문 ID', 'acf-css-woo-license' ); ?></th>
                            <th><?php esc_html_e( '고객', 'acf-css-woo-license' ); ?></th>
                            <th><?php esc_html_e( '에디션', 'acf-css-woo-license' ); ?></th>
                            <th><?php esc_html_e( '라이센스 키', 'acf-css-woo-license' ); ?></th>
                            <th><?php esc_html_e( '날짜', 'acf-css-woo-license' ); ?></th>
                            <th><?php esc_html_e( '상태', 'acf-css-woo-license' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $orders = $this->get_recent_orders_with_licenses();
                        if ( empty( $orders ) ) : ?>
                            <tr><td colspan="6"><?php esc_html_e( '내역이 없습니다.', 'acf-css-woo-license' ); ?></td></tr>
                        <?php else : 
                            foreach ( $orders as $order ) : ?>
                            <tr>
                                <td>#<?php echo esc_html( $order['order_id'] ); ?></td>
                                <td><?php echo esc_html( $order['customer'] ); ?></td>
                                <td><span class="jj-pill"><?php echo esc_html( strtoupper( $order['edition'] ) ); ?></span></td>
                                <td><code><?php echo esc_html( $order['license_key'] ); ?></code></td>
                                <td><?php echo esc_html( $order['date'] ); ?></td>
                                <td><?php echo $order['status'] ? '✅ 발행됨' : '❌ 실패'; ?></td>
                            </tr>
                        <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <style>
            .jj-pill { background: #f0f0f1; padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        </style>
        <?php
    }

    /**
     * 최근 주문 및 라이센스 정보 가져오기
     */
    private function get_recent_orders_with_licenses() {
        // 실제 데이터베이스 쿼리로 구현될 부분
        // 여기서는 예시 데이터를 반환합니다.
        return array(
            array(
                'order_id' => '1234',
                'customer' => 'test@example.com',
                'edition'  => 'unlimited',
                'license_key' => 'ACF-XXXX-XXXX-XXXX',
                'date' => '2026-01-03',
                'status' => true
            )
        );
    }

    private function get_monthly_sales_count() { return 15; }
    private function get_active_license_count() { return 120; }
    private function get_partner_earnings() { return 450000; }
}

// 초기화
JJ_Woo_License_Dashboard::instance();
